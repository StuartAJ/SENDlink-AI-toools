// Shared UI Components
//
// Components shared between the SLT and TeachMate dashboards such as
// navigation bars, modals and form elements will live here. This
// placeholder exports nothing for now.

export default {};