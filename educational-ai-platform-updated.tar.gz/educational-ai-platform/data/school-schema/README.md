# School Schema Data

This directory holds sample data and templates for the `schoolSchema` used by the platform. During development, example JSON files representing your school's profile, policies and performance data can be stored here. These files will be referenced by API endpoints and integration tests.