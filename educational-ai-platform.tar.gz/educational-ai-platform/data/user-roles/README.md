# User Roles Data

This directory contains example user role definitions and sample user accounts. Each file demonstrates how roles map to permissions and dashboards defined in the `userRoleSchema`. Use these samples for testing authentication and authorisation features.