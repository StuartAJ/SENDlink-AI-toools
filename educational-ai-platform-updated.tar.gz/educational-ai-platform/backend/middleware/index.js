// Backend Middleware
//
// This directory will contain middleware functions for authentication,
// logging, error handling and more. For now, this placeholder exports an
// empty object so that imports do not fail.

export default {};