// Frontend Pages
//
// Entry point for the web application. This placeholder exports a minimal
// component until the UI is implemented. In a real project this would be
// replaced with page routing logic (e.g. Next.js pages).

export default function HomePage() {
  return null;
}