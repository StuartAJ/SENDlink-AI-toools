// Frontend Utilities
//
// Shared utility functions for the frontend application. This might include
// data formatting, API helpers and other reusable logic. Currently
// exported as an empty object.

export default {};